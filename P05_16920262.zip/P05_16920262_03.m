% NIM / Nama    : 16920262 / Octavianus Bagaswara Adi
% Tanggal       : 17 Desember 2020 
% Deskripsi     : visualisasi data nilai mata uang

% membaca tabel
T = readtable('crypto.csv');
% pembersihan command windows
clc

% Line chart untuk harga BTC setiap harinya. Gunakan nilai close sebagai nilai harian.
fprintf("Soal 1. Line chart untuk harga BTC setiap harinya. Akan diunakan nilai close sebagai nilai harian. \n")

condBTC = T.name == "BTC";
figure(1)
plot(T.date(condBTC,:),T.close(condBTC,:));
grid on; xlabel("Tanggal"); ylabel("Harga Close");
title("Harga BTC setiap harinya");
%{
Soal 1. Line chart untuk harga BTC setiap harinya. Akan diunakan nilai close sebagai nilai harian. 
%}

% Scatter Plot dengan nilai high sebagai sumbu x dan nilai low sebagai sumbu y untuk koin ETH
fprintf("Soal 2. Scatter Plot dengan nilai high sebagai sumbu x dan nilai low sebagai sumbu y untuk koin ETH. \n")

condETH = T.name == "ETH";
figure(2)
scatter(T.high(condETH,:),T.low(condETH,:),[],"blue",".")
grid on; xlabel("Nilai High"); ylabel("Nilai Low");
title("Nilai High sebagai Sumbu x dan Nilai Low sebagai Sumbu y untuk Koin ETH");
%{
Soal 2. Scatter Plot dengan nilai high sebagai sumbu x dan nilai low sebagai sumbu y untuk koin ETH. 
%}


% Pie chart banyaknya data dari masing-masing koin
fprintf("Soal 3. Pie chart banyaknya data dari masing-masing koin. \n")

figure(3)
pie(categorical(T.name))
title("Banyak Data dari Masing-Masing Koin");
%{
Soal 3. Pie chart banyaknya data dari masing-masing koin. 
%}

% Pie chart nilai kapitalisasi pasar semua mata uang pada tanggal 4 Juli 2016
fprintf("Soal 4. Pie chart nilai kapitalisasi pasar semua mata uang pada tanggal 4 Juli 2016. \n")

figure(4)
condDATE = T.date == datetime("7/4/2016",'InputFormat',"M/d/uuuu");
pie(categorical(T.market(condDATE,:)))
title("Nilai Kapitalisasi Pasar Semua Mata Uang pada Tanggal 4 Juli 2016")
%{
Soal 4. Pie chart nilai kapitalisasi pasar semua mata uang pada tanggal 4 Juli 2016. 
%}

% Line chart untuk membandingkan nilai high BTC, ETH, XRP, USDT, dan XMR
fprintf("Soal 5. Line chart untuk membandingkan nilai high BTC, ETH, XRP, USDT, dan XMR. \n")

x = unstack(T,"high","name");
figure(5)
plot(x.date, [x.BTC x.ETH x.XRP x.USDT x.XMR]);
grid on; xlabel("Tanggal"); ylabel("Harga High");
legend({'BTC','ETH','XRP','USDT','XMR'},'Location','eastoutside')
title("Harga BTC setiap harinya");
%{
Soal 5. Line chart untuk membandingkan nilai high BTC, ETH, XRP, USDT, dan XMR. 
%}