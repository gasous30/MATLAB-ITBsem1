% NIM / Nama    : 16920262 / Octavianus Bagaswara Adi
% Tanggal       : 17 Desember 2020 
% Deskripsi     : analisa data nilai mata uang

% membaca tabel
T = readtable('crypto.csv');
% pembersihan command windows
clc

% Banyaknya data
fprintf("Soal 1. Banyak data. \nBanyaknya data ada ada %d \n",height(T));
%{
Soal 1. Banyak data. 
Banyaknya data ada ada 8219
%} 

% 5 Data pertama
fprintf("Soal 2. 5 Data pertama.\n");
T(1:5,:)
%{
Soal 2. 5 Data pertama.

ans =

  5×11 table

     name         date       ranknow     open      high      low      close     volume      market      close_ratio    spread
    _______    __________    _______    ______    ______    ______    ______    ______    __________    ___________    ______

    {'BTC'}    2013-04-28       1        135.3    135.98     132.1    134.21      0       1.4886e+09      0.5438        3.88 
    {'BTC'}    2013-04-29       1       134.44    147.49       134    144.54      0       1.6038e+09      0.7813       13.49 
    {'BTC'}    2013-04-30       1          144    146.93    134.05       139      0       1.5428e+09      0.3843       12.88 
    {'BTC'}    2013-05-01       1          139    139.89    107.72    116.99      0        1.299e+09      0.2882       32.17 
    {'BTC'}    2013-05-02       1       116.38     125.6     92.28    105.21      0       1.1685e+09      0.3881       33.32 

%}

% Data ke 406 sampai ke 410
fprintf("Soal 3. Data ke 406 sampai 410.\n");
T(406:410,:)
%{
Soal 3. Data ke 406 sampai 410.

ans =

  5×11 table

     name         date       ranknow     open      high      low      close       volume        market      close_ratio    spread
    _______    __________    _______    ______    ______    ______    ______    __________    __________    ___________    ______

    {'BTC'}    2014-06-07       1       653.52    656.94    644.91    654.97    1.5855e+07    8.4282e+09      0.8362       12.03 
    {'BTC'}    2014-06-08       1       654.99    658.88    653.47    656.14    8.6142e+06    8.4455e+09      0.4935        5.41 
    {'BTC'}    2014-06-09       1       655.64     657.7    644.39    649.16    1.9065e+07    8.3581e+09      0.3584       13.31 
    {'BTC'}    2014-06-10       1       650.04    659.61    646.56    653.15    1.7913e+07    8.4123e+09       0.505       13.05 
    {'BTC'}    2014-06-11       1       653.19    657.04    632.55    633.02    2.5164e+07    8.1553e+09      0.0192       24.49 
%}

% Jumlah data masing-masing koin
fprintf("Soal 4. Jumlah data masing-masing koin.\n");
tabulate(T.name)
%{
Soal 4. Jumlah data masing-masing koin.
  Value    Count   Percent
    BTC     2042     24.84%
    XRP     1944     23.65%
    ETH     1211     14.73%
   USDT     1369     16.66%
    XMR     1653     20.11%
%}

% Nilai korelasi antara nilai volume dan nilai close
fprintf("Soal 5. Nilai korelasi antara nilai volume dan nilai close.\n");
corr(T.volume,T.close_ratio)
fprintf("Karena nilai korelasi mendekati 0, maka kedua nilai tidak berkolerasi. \nPerubahan nilai volume tidak akan mempengaruhi nilai close ratio.\n");
%{
Soal 5. Nilai korelasi antara nilai volume dan nilai close.

ans =

    0.0693

Karena nilai korelasi mendekati 0, maka kedua nilai tidak berkolerasi. 
Perubahan nilai volume tidak akan mempengaruhi nilai close ratio.
%}

