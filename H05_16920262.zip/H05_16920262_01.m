% NIM / Nama    : 16920262 / Octavianus Bagaswara Adi
% Tanggal       : 14 Desember 2020 (submit), 17 Desember 2020 (praktikum)
% Deskripsi     : analisa data nilai uas, mencari banyak data, 10 data pertama, data ke 50 sampai ke 60, mahasiswa tiap fakultas, dan nilai korelasi

% membaca tabel
data = readtable('nilai_uas.csv');
% pembersihan command windows
clc

% Banyaknya data
fprintf("Soal 1. Banyaknya data ada %d \n",height(data));
% Soal 1. Banyaknya data ada 3562

% 10 data pertama
fprintf("Soal 2. Cetak 10 data pertama. \n");
data(1:10,:)
%{ 
Soal 2. Cetak 10 data pertama. 

ans =

  10×5 table

             nama              fakultas     nilai_kal    nilai_fis    nilai_kim
    _______________________    _________    _________    _________    _________

    {'Raihan Daris'       }    {'SF'   }      60.27        65.59         51.7  
    {'Galuh Wina'         }    {'STEI' }      52.99        55.25        66.31  
    {'Johannes Sun'       }    {'FMIPA'}       51.2         51.3         84.7  
    {'Abdurrahman WIlliam'}    {'FTSL' }      31.17        36.88        50.25  
    {'Rayhan Faris'       }    {'STEI' }      55.55        57.61        67.46  
    {'Margareth Widyatama'}    {'FTTM' }      42.78        50.23        71.17  
    {'Christofer Jaza'    }    {'FTSL' }      31.64        38.03        34.99  
    {'Wafika Nadia'       }    {'SF'   }      60.96        57.54        76.03  
    {'Elizabeth Parikesit'}    {'STEI' }      54.35         55.3        59.15  
    {'Halida Aqila'       }    {'SITHR'}      63.71        67.23        63.76  
%}

% Data ke 50 sampai 60
fprintf("Soal 3. Cetak data ke 50 sampai data ke 60. \n");
data(50:60,:)
%{
Soal 3. Cetak data ke 50 sampai data ke 60. 

ans =

  11×5 table

            nama             fakultas     nilai_kal    nilai_fis    nilai_kim
    _____________________    _________    _________    _________    _________

    {'Kenesha Monica'   }    {'FTTM' }      41.63        39.58        61.25  
    {'Ulul Mochammad'   }    {'FTTM' }      38.75        44.24        40.11  
    {'George Vrince'    }    {'FITB' }      44.02        45.15        41.76  
    {'Fayza Eunike'     }    {'STEI' }      55.28        59.47        49.29  
    {'Kevin Faustin'    }    {'SAPPK'}      47.72        49.65        52.76  
    {'salah Siagian'    }    {'SAPPK'}      47.14        51.26        46.77  
    {'Nabilah Satya'    }    {'SF'   }      61.26        63.96        57.19  
    {'Tharisa Ghiffari' }    {'FSRD' }      74.14        78.86        54.59  
    {'Setyawan Ahmad'   }    {'FSRD' }      75.18        78.33        51.35  
    {'Kelvin Salsabiela'}    {'FTTM' }      39.69        40.92        51.15  
    {'Sitorus Aidil'    }    {'FTMD' }      58.49        55.54         55.2  
%}

% Banyaknya mahasiswa tiap fakultas
fprintf("Soal 4. Cetak banyak mahasiswa tiap fakultas. \n");
tabulate(data.fakultas)
%{
Soal 4. Cetak banyak mahasiswa tiap fakultas. 
  Value    Count   Percent
     SF      154      4.32%
   STEI      499     14.01%
  FMIPA      396     11.12%
   FTSL      424     11.90%
   FTTM      454     12.75%
  SITHR      179      5.03%
   FTMD      352      9.88%
    SBM      261      7.33%
   FSRD      260      7.30%
  SITHS      102      2.86%
  SAPPK      198      5.56%
   FITB      283      7.94%
%}

% Nilai korelasi antara kalkulus dan fisika
fprintf("Soal 5. Cari nilai korelasi antara kalkulus dan fisika. \n");
Kalkulus = data{:,3};
Fisika = data{:,4};
corrcoef(Kalkulus,Fisika)
% Karena nilai korelasi yang didapat semakin mendekati 1, maka nilai kalkulus dan nilai fisika berbanding lurus
fprintf("Karena nilai korelasi semakin mendekati 1, maka nilai kalkulus dan nilai fisika berbanding lurus. \n");
%{
Soal 5. Cari nilai korelasi antara kalkulus dan fisika. 

ans =

    1.0000    0.9605
    0.9605    1.0000

Karena nilai korelasi semakin mendekati 1, maka nilai kalkulus dan nilai fisika berbanding lurus. 
%}