% NIM / Nama    : 16920262 / Octavianus Bagaswara Adi
% Tanggal       : 14 Desember 2020 (submit), 17 Desember 2020 (praktikum)
% Deskripsi     : analisa data nilai uas, visualisasi data dalam diagram

% membaca tabel
data = readtable('nilai_uas.csv');
% pembersihan command window
clc

% Histogram Distribusi Nilai Kalkulus
fprintf("Soal 1. Histrogram Distribusi Nilai Kalkulus. \n");
% membuat diagram
figure(1);
histogram(data.nilai_kal); grid on
xlabel('Nilai'); ylabel('Frekuensi');
title('Histrogram Distribusi Nilai Kalkulus');
% Soal 1. Histrogram Distribusi Nilai Kalkulus. (detil di Figure 1)

% Diagram batang horizontal banyaknya mahasiswa masing-masing fakultas
fprintf("Soal 2. Diagram Batang Horizontal Banyaknya Mahasiswa Masing-masing Fakultas. \n");
% membuat tabel frekuensi fakultas
x = cell2table (tabulate(data{:,"fakultas"}));
% membuat diagram
figure(2)
barh(x.Var2);
set(gca,'yticklabel',x.Var1); grid on
xlabel('Banyak Mahasiswa'); ylabel('Fakultas');
title("Banyaknya Mahasiswa Masing-masing Fakultas");
% Soal 2. Diagram Batang Horizontal Banyaknya Mahasiswa Masing-masing Fakultas. (detil di Figure 2)

% Diagram batang horizontal banyaknya mahasiswa masing-masing fakultas
fprintf("Soal 3. Diagram Pie Banyaknya Mahasiswa Masing-masing Fakultas. \n");

figure(3)
pie(categorical(data.fakultas))
title("Banyaknya Mahasiswa Masing-masing Fakultas");
% Soal 3. Diagram Pie Banyaknya Mahasiswa Masing-masing Fakultas. (detil di Figure 3)

% Fakultas dengan Mahasiswa Terbanyak
fprintf("Soal 4. Fakultas dengan Mahasiswa Terbanyak. \n");
[valmax,idxmax] = max(x.Var2); % mencari frekuensi fakultas terbesar
fprintf("Fakultas dengan mahasiswa terbanyak adalah %s \n",string(x{idxmax:idxmax,"Var1"}));
fprintf("Diagram yang menunjukkan mahasiswa terbanyak per fakultas terbaik adalah diagram batang horizontal. \nIni disebabkan karena diagram pie sulit untuk dilihat. Besar bagian lingkaran antarfakultas kurang lebih sama sehingga sulit untuk dibedakan. \nPada diagram batang, perbedaan panjang batang terlihat jelas sehingga bisa dibedakan secara lebih cepat dan mudah fakultas yang memiliki mahasiswa terbanyak. \n");
%{
Soal 4. Fakultas dengan Mahasiswa Terbanyak. 
Fakultas dengan mahasiswa terbanyak adalah STEI 
Diagram yang menunjukkan mahasiswa terbanyak per fakultas terbaik adalah diagram batang horizontal. 
Ini disebabkan karena diagram pie sulit untuk dilihat. Besar bagian lingkaran antarfakultas kurang lebih sama sehingga sulit untuk dibedakan. 
Pada diagram batang, perbedaan panjang batang terlihat jelas sehingga bisa dibedakan secara lebih cepat dan mudah fakultas yang memiliki mahasiswa terbanyak.
%}

% Scatter Plot 
fprintf("Soal 5. Scatter Plot dengan Nilai Kimia sebagai sumbu x dan Nilai Fisika sebagai sumbu y. \n");

figure(4)
scatter(data.nilai_kim,data.nilai_fis,[],"blue",".")
grid on; xlabel('Nilai Kimia'); ylabel('Nilai Fisika');
title("Nilai Kimia sebagai sumbu x dan Nilai Fisika sebagai sumbu y");
% Soal 5. Scatter Plot dengan Nilai Kimia sebagai sumbu x dan Nilai Fisika sebagai sumbu y. (detil di Figure 4)