% NIM / Nama    : 16920262 / Octavianus Bagaswara Adi
% Tanggal       : 14 Desember 2020 (submit), 17 Desember 2020 (praktikum)
% Deskripsi     : analisa data nilai uas, mencari nilai tuan Mor, nilai fisika tertinggi, kimia tertinggi, nilai kalkulus dibawah 50, dan banyaknya mahasiswa FMIPA

% membaca tabel
data = readtable('nilai_uas.csv');
% pembersihan command window
clc

% Cetak nilai kalkulus, fisika, dan kimia Tuan Mor
fprintf("Soal 1. Nilai Tuan Mor. \n");
condMor = data.nama == "Tuan Mor"; % pencarian baris dengan nama Tuan Mor
fprintf("Nilai Kalkulus Tuan Mor adalah %.2f \n",data{condMor,"nilai_kal"});
fprintf("Nilai Fisika Tuan Mor adalah %.2f \n",data{condMor,"nilai_fis"});
fprintf("Nilai Kimia Tuan Mor adalah %.2f \n \n",data{condMor,"nilai_kim"});
%{
Soal 1. Nilai Tuan Mor. 
Nilai Kalkulus Tuan Mor adalah 94.76 
Nilai Fisika Tuan Mor adalah 67.50 
Nilai Kimia Tuan Mor adalah 24.82 
%}

% Cetak mahasiswa dengan nilai fisika tertinggi
fprintf("Soal 2. Nama mahasiswa dengan nilai fisika tertinggi. \n");
[valmax,idxmax] = max(data.nilai_fis);
condFISMAX = data.nilai_fis == valmax;
fprintf("Mahasiswa dengan nilai fisika tertinggi adalah %s \n \n",string(data{condFISMAX,"nama"})); % menampilkan nama mahasiswa dengan nilai fisika tertinggi
%{
Soal 2. Nama mahasiswa dengan nilai fisika tertinggi. 
Mahasiswa dengan nilai fisika tertinggi adalah Cahyani Mora
%}

% Cetak 10 mahasiswa dengan nilai kimia tertinggi
fprintf("Soal 3. 10 Mahasiswa dengan nilai kimia tertinggi. \n");
kim = sortrows(data,"nilai_kim","descend");
kim(1:10,"nama") % menampilkan nama mahasiswa dengan nilai kimia 10 tertinggi
%{
Soal 3. 10 Mahasiswa dengan nilai kimia tertinggi. 

ans =

  10×1 table

            nama        
    ____________________

    {'Muhammadi Jumhur'}
    {'Maria Manurung'  }
    {'Grace Yoga'      }
    {'Dhiya Wafa'      }
    {'Rasyid FH'       }
    {'Sukma Ulhaq'     }
    {'WIJAYANTI Amadio'}
    {'Rizam Rayhan'    }
    {'Jevon Tangguh'   }
    {'Ediva zilva'     }
%}


% Cetak banyaknya mahasiswa yang mendapat nilai kalkulus dibawah 50
fprintf("Soal 4. Banyak Mahasiswa dengan nilai kalkulus dibawah 50. \n");
condKAL = data.nilai_kal < 50; % mencari data dengan nilai kalkulus dibawah 50
fprintf("Banyaknya mahasiswa yang mendapat nilai kalkulus di bawah 50 ada %d \n \n",height(data(condKAL,:)));
%{
Soal 4. Banyak Mahasiswa dengan nilai kalkulus dibawah 50. 
Banyaknya mahasiswa yang mendapat nilai kalkulus di bawah 50 ada 1549 
%}

% Cetak banyaknya mahasiswa FMIPA
fprintf("Soal 5. Banyak Mahasiswa FMIPA. \n");
condFMIPA = data.fakultas == "FMIPA"; % mencari data dengan fakultas FMIPA
fprintf("Banyaknya mahasiswa FMIPA ada %d \n",height(data(condFMIPA,:)));
%{
Soal 5. Banyak Mahasiswa FMIPA. 
Banyaknya mahasiswa FMIPA ada 396 
%}