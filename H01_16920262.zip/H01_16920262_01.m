% NIM/Nama  : 16920262 / Octavianus Bagaswara Adi
% Tanggal   : Senin, 19 Oktober 2020 (submit), 22 Oktober 2020 (Praktikum)
% Deskripsi : menuliskan "Hello, World" ke layar

%pembersihan command line
clc

% mencetak kata "Hello, World!"
fprintf("Hello, World!");